function equalfunc(){
    var oprand=document.getElementById("res").innerHTML;
    var array=oprand.split(/\D/);
    var op;
    for(let s of oprand)
        if(s!=1 && s!=0)
            op=s;
    var z=parseInt(array[0],2);
    var x=parseInt(array[1],2);
    var result;
    switch(op){
        case '+':
            result=z+x;
            break;
        case '-':
            result=z-x;
            break;
        case '*':
            result=z*x;
            break;
        case '/':
            result=parseInt(z/x);
            break;
        default:
            result=0;
            break;
    }
    var bin=(result>>>0).toString(2);
    document.getElementById("res").innerHTML=bin.toString();
    
}